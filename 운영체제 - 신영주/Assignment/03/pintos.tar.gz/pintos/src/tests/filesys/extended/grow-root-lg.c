/* Creates 50 files in the root directory. */

#define FILE_CNT 50
#include "tests/filesys/extended/grow-dir.inc"
