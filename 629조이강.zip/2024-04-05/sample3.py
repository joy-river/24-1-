a = [1, 2, 3]
if 2 in a:
    print('합격을 축하합니다.')
else:
    print("꽝, 다음 기회에!")
