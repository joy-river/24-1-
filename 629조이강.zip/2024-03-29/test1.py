def hello():
    print("Hi, Yigang Jo")


hello()
