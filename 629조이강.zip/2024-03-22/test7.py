i = 1
while True:
    print(i)
    if i == 2024:
        break
    i += 1
