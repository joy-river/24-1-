a = 8
if a % 2 == 0:
    print(a)
    print("짝수")
else:
    print(a)
    print("홀수")

print("종료")
