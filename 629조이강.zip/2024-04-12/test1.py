x = '123456789'
print(x[2])
print(x[3])
print(x[6])

y = 123456789
print(y)

z = y / 10
print(z)
z = y // 10
print(z)

z = y // 1000000
print(z)
w = z % 10
print(w)

z = y // 100000
print(z)
w = z % 10
print(w)

z = y // 100
print(z)
w = z % 10
print(w)
