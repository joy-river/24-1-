a = 10
if a % 2 == 0: print(a)

print("종료")
