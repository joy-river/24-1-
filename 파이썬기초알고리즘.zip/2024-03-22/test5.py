a = 1
b = 1
print(a)
print(b)
for x in range(3, 48):
    c = a + b
    print(c)
    a = b
    b = c
