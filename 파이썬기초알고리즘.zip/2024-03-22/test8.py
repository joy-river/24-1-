a = 1
b = 1
print(a)
print(b)
c = a + b
while c <= 2019320097:
    c = a + b
    print(c)
    a = b
    b = c
