for x in range(5, 15):
    print(2 * x)
    print(2 * x + 1)
