a = [2000, 11, 22]
for x in a:
    print(2 * x)
    print(2 * x + 1)
