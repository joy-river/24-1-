a = 2019320097

if a % 6 == 1:
    print(a)
    print("One")
elif a % 6 == 2:
    print(a)
    print("Two")
elif a % 6 == 3:
    print(a)
    print("Three")
elif a % 6 == 4:
    print(a)
    print("Four")
elif a % 6 == 5:
    print(a)
    print("Five")
else:
    print(a)
    print("Six")

print("종료")
