def hello():
    print('HI, Im Jo Yigang')
    hello()

hello()
