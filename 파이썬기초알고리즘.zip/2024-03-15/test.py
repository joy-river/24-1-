a = 10
if a % 2 == 0:
    print(a)
    print("짝수")
print("종료")
