def square(a):
    print(a * a)


square(8)


def square2(a):
    return a*a


b = square2(9)
print(b)
print(square2(10))

c = square2(3) * square2(4)
print(c)
